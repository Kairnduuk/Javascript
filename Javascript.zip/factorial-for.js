// Este archivo debe calcular el factorial de 10 utilizando un solo bucle for
const numero = 10;

for (let i = 0; i< numero; i++ ) {
    console.log(i*numero);

};
