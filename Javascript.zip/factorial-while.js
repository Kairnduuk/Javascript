// factorial-while.js -> Este archivo debe calcular el factorial de 10 utilizando un bucle while
const numero = 10;
let i = 0;

while (i< numero) {
    console.log(i*numero);
    i++;
};
